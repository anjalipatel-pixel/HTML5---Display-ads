// Google Ads clickTag handler
(function () {
  var container = document.getElementById('ad-container');
  if (container) {
    container.addEventListener('click', function () {
      window.open(window.clickTag, '_blank');
    });
  }
})();

// 3-image carousel — left-side content is static; only the right-side
// product image (and its blurred backdrop) cycles, each with its own
// duration and its own entrance/exit motion.
(function () {
  var stageImgs = document.querySelectorAll('.stage-img');
  var bgImgs = document.querySelectorAll('.bg-stage-img');
  var slideCopies = document.querySelectorAll('.slide-copy');
  var banner = document.querySelector('.banner');
  if (!stageImgs.length) return;

  var STAGES = [
    { anim: 'stageFadeHold', duration: 7500 }, // AI-opt: Before +1s, After group1 +1s, group2 +1s
    { anim: 'stageFadeHold', duration: 9000 }, // Feed scan, Customer Match List, Local Inventory, Facebook Sets — each phase +0.5s
    { anim: 'stageFadeHold', duration: 3500 }  // setup: has the most copy, gets more time on screen
  ];

  // Play order: "What's new since you left?" features first, then the
  // AI-optimisation stage, then the feed-sync stage. Each entry is the
  // stage's data-stage index, so all per-stage timings/CSS stay as-is.
  var ORDER = [1, 0, 2];

  function restartCardAnimation(el) {
    // Stage 0 plays a Before card -> AI icon -> After card sequence driven by
    // CSS animations on the phase wrappers (and the shoe entrance). Those need
    // an explicit reflow-restart each time the stage comes back around.
    var parts = el.querySelectorAll('.ai-phase, .ai-const-left, .pt-before, .pt-after, .after-group, .growth-graph, .growth-label, .shoe-thumb, .ai-check-row, .scan-row, .typing-text, .feed-phase, .local-tile, .map-photo, .fb-card, .fb-item, .fb-arrows, .fb-arrow, .fb-grid img, .cml-ad-card, .cml-target, .cml-p, .sync-side-text, .sync-store-shrink, .sync-browser, .sync-store-card, .sync-woo-logo, .sync-cart-badge, .sync-tile, .sync-down-arrow, .sync-spinner, .sync-branch, .sync-dest-card');
    if (!parts.length) return;
    parts.forEach(function (p) { p.style.animation = 'none'; });
    el.offsetHeight; // force reflow
    parts.forEach(function (p) { p.style.animation = ''; });
  }

  function showStage(pos) {
    var i = ORDER[pos];
    if (banner) banner.setAttribute('data-active-stage', i);
    stageImgs.forEach(function (el, idx) {
      if (idx === i) {
        el.classList.add('active');
        el.style.animation = 'none';
        el.offsetHeight; // force reflow so the animation restarts
        el.style.animation = STAGES[i].anim + ' ' + STAGES[i].duration + 'ms linear forwards';
        restartCardAnimation(el);
      } else {
        el.classList.remove('active');
        el.style.animation = 'none';
      }
    });
    bgImgs.forEach(function (el, idx) {
      el.classList.toggle('active', idx === i);
      el.style.opacity = idx === i ? '0.4' : '0';
    });
    slideCopies.forEach(function (el, idx) {
      el.classList.toggle('active', idx === i);
    });
    setTimeout(function () {
      showStage((pos + 1) % ORDER.length);
    }, STAGES[i].duration);
  }

  showStage(0);
})();
